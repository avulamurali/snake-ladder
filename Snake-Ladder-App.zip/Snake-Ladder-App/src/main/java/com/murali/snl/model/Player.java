package com.murali.snl.model;

import org.springframework.stereotype.Component;

import java.util.Random;
import java.util.UUID;

public class Player {
    private String name;
    private String id;

    public Player(String name) {
        this.name = name;
        this.id = getRandomNumberString();
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    private String getRandomNumberString() {
        // It will generate 6 digit random Number.
        // from 0 to 999999
        Random rnd = new Random();
        int number = rnd.nextInt(999999);

        // this will convert any number sequence into 6 character.
        return String.format("%06d", number);
    }
}
