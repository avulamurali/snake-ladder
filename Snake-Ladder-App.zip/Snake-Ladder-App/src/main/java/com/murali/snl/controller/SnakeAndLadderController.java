package com.murali.snl.controller;

import com.murali.snl.model.Ladder;
import com.murali.snl.model.Player;
import com.murali.snl.model.PlayerResponse;
import com.murali.snl.model.Snake;
import com.murali.snl.service.SnakeAndLadderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@RestController(value ="/snakes-ladder")
public class SnakeAndLadderController {

    @Autowired
    SnakeAndLadderService snakeAndLadderService;

    @RequestMapping(value = "/players",method = RequestMethod.POST)
    public ResponseEntity<PlayerResponse> registerPlayer(@RequestBody String name ) {
        PlayerResponse response= new PlayerResponse();
        boolean isPlayerPresent = snakeAndLadderService.isPlayerAlreadyPresent(name);
        if(isPlayerPresent) {
            response.setMessage("Please add unique name");
        } else {
            Player player = snakeAndLadderService.addPlayer(name);
            response.setPlayerName(player.getName());
            response.setPlayerId(player.getId());
        }
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value ="/players/{playerId}/roll", method = RequestMethod.GET)
    public ResponseEntity<PlayerResponse> rollDice(@PathVariable String playerId) {
        return ResponseEntity.ok(snakeAndLadderService.rollDice(playerId));
    }

    @RequestMapping(value ="/players/{playerId}/completed", method = RequestMethod.GET)
    public ResponseEntity<Boolean> hasPlayerCopleted(@PathVariable String playerId) {
        return ResponseEntity.ok(snakeAndLadderService.hasPlayerWonGame(playerId));
    }

    @RequestMapping(value ="/start", method = RequestMethod.GET)
    public ResponseEntity startGame() {
        boolean isGameStarted=snakeAndLadderService.startGame();
        if(!isGameStarted){
            new ResponseEntity<>("Please add minimum no of players to start", HttpStatus.OK);
        }
        return new ResponseEntity<>("Game started successfully", HttpStatus.OK);
    }

}
