package com.murali.snl.model;

public class PlayerResponse {
    private String playerId;
    private String playerName;
    private boolean hasGameCompleted;
    private int oldPosition;
    private int newPosition;
    private int diceRolled;
    private String message;

    public String getPlayerId() {
        return playerId;
    }

    public void setPlayerId(String playerId) {
        this.playerId = playerId;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public boolean isHasGameCompleted() {
        return hasGameCompleted;
    }

    public void setHasGameCompleted(boolean hasGameCompleted) {
        this.hasGameCompleted = hasGameCompleted;
    }

    public int getOldPosition() {
        return oldPosition;
    }

    public void setOldPosition(int oldPosition) {
        this.oldPosition = oldPosition;
    }

    public int getNewPosition() {
        return newPosition;
    }

    public void setNewPosition(int newPosition) {
        this.newPosition = newPosition;
    }

    public int getDiceRolled() {
        return diceRolled;
    }

    public void setDiceRolled(int diceRolled) {
        this.diceRolled = diceRolled;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
