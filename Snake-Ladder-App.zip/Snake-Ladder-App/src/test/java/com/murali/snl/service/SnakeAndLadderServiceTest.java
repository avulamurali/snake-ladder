package com.murali.snl.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

public class SnakeAndLadderServiceTest {

    private SnakeAndLadderService snakeAndLadderService;

    @Before
    public void init() {
        this.snakeAndLadderService = new SnakeAndLadderService(100);
        this.snakeAndLadderService.addPlayer("mk");
        this.snakeAndLadderService.addPlayer("gk");
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testIsGameCompleted() {
        Assert.assertEquals(snakeAndLadderService.isGameCompleted() ,false);
    }

    @Test
    public void testStartGameDriver(){
        snakeAndLadderService.startGameDriver();
        Assert.assertEquals(snakeAndLadderService.isGameCompleted() ,true);
    }

}
